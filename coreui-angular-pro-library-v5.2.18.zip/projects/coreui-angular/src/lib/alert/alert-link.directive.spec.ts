import { AlertLinkDirective } from './alert-link.directive';

describe('AlertLinkDirective', () => {
  it('should create an instance', () => {
    const directive = new AlertLinkDirective();
    expect(directive).toBeTruthy();
  });
});
