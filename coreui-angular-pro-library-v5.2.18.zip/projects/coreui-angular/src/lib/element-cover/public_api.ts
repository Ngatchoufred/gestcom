export { ElementCoverComponent } from './element-cover.component';
export { ElementCoverModule } from './element-cover.module';
