export { PlaceholderAnimationDirective } from './placeholder-animation.directive';
export { PlaceholderDirective } from './placeholder.directive';
export { PlaceholderModule } from './placeholder.module';
