export { CalloutComponent } from './callout.component';
export { CalloutModule } from './callout.module';
