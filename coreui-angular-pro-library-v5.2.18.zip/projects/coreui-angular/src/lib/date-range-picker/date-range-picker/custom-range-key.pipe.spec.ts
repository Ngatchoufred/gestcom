import { CustomRangeKeyPipe } from './custom-range-key.pipe';

describe('CustomRangeKeyPipe', () => {
  it('create an instance', () => {
    const pipe = new CustomRangeKeyPipe();
    expect(pipe).toBeTruthy();
  });
});
