export { DateRangePickerComponent, ICalendarRanges } from './date-range-picker/date-range-picker.component';
export { DateRangePickerModule } from './date-range-picker.module';
