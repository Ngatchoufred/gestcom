import { CalendarDayTitlePipe } from './calendar-day-title.pipe';

describe('CalendarDayTitlePipe', () => {
  it('create an instance', () => {
    const pipe = new CalendarDayTitlePipe();
    expect(pipe).toBeTruthy();
  });
});
