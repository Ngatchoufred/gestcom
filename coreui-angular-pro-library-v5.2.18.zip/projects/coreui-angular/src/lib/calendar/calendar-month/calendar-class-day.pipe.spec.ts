import { CalendarClassDayPipe } from './calendar-class-day.pipe';

describe('CalendarClassDayPipe', () => {
  it('create an instance', () => {
    const pipe = new CalendarClassDayPipe();
    expect(pipe).toBeTruthy();
  });
});
