import { CalendarClassRowPipe } from './calendar-class-row.pipe';

describe('CalendarClassRowPipe', () => {
  it('create an instance', () => {
    const pipe = new CalendarClassRowPipe();
    expect(pipe).toBeTruthy();
  });
});
