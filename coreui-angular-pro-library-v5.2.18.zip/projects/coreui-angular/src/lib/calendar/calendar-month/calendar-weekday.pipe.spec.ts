import { CalendarWeekdayPipe } from './calendar-weekday.pipe';

describe('CalendarWeekdayPipe', () => {
  it('create an instance', () => {
    const pipe = new CalendarWeekdayPipe();
    expect(pipe).toBeTruthy();
  });
});
