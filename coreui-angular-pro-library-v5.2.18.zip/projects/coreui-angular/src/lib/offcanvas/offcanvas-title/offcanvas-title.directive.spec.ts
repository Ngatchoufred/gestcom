import { OffcanvasTitleDirective } from './offcanvas-title.directive';

describe('OffcanvasTitleDirective', () => {
  it('should create an instance', () => {
    const directive = new OffcanvasTitleDirective();
    expect(directive).toBeTruthy();
  });
});
