import { NavbarBrandDirective } from './navbar-brand.directive';

describe('NavbarBrandDirective', () => {
  it('should create an instance', () => {
    const directive = new NavbarBrandDirective();
    expect(directive).toBeTruthy();
  });
});
