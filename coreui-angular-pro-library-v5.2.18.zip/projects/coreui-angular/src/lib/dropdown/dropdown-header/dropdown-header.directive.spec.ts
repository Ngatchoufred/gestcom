import { DropdownHeaderDirective } from './dropdown-header.directive';

describe('DropdownHeaderDirective', () => {
  it('should create an instance', () => {
    const directive = new DropdownHeaderDirective();
    expect(directive).toBeTruthy();
  });
});
