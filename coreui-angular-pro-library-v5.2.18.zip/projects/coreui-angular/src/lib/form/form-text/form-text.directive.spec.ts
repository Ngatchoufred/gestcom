import { FormTextDirective } from './form-text.directive';

describe('FormTextDirective', () => {
  it('should create an instance', () => {
    const directive = new FormTextDirective();
    expect(directive).toBeTruthy();
  });
});
