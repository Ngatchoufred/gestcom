import { FormFloatingDirective } from './form-floating.directive';

describe('FormFloatingDirective', () => {
  it('should create an instance', () => {
    const directive = new FormFloatingDirective();
    expect(directive).toBeTruthy();
  });
});
