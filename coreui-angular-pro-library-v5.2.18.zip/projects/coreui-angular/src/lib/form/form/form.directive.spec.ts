import { FormDirective } from './form.directive';

describe('FormDirective', () => {
  it('should create an instance', () => {
    const directive = new FormDirective();
    expect(directive).toBeTruthy();
  });
});
