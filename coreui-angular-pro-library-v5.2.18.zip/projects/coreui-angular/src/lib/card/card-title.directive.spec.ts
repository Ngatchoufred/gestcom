import { CardTitleDirective } from './card-title.directive';

describe('CardTitleDirective', () => {
  it('should create an instance', () => {
    const directive = new CardTitleDirective();
    expect(directive).toBeTruthy();
  });
});
