import { CardSubtitleDirective } from './card-subtitle.directive';

describe('CardSubtitleDirective', () => {
  it('should create an instance', () => {
    const directive = new CardSubtitleDirective();
    expect(directive).toBeTruthy();
  });
});
