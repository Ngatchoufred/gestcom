import { ModalTitleDirective } from './modal-title.directive';

describe('ModalTitleDirective', () => {
  it('should create an instance', () => {
    const directive = new ModalTitleDirective();
    expect(directive).toBeTruthy();
  });
});
